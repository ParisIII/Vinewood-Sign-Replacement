fx_version 'cerulean'
game 'gta5'
description 'maps'

this_is_a_map 'yes'